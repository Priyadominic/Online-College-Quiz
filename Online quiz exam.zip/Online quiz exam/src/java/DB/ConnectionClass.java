/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Ammu
 */
public class ConnectionClass {
    Connection con=null;
    Statement st=null;
    public ResultSet rs=null;
    public ConnectionClass()
    {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3307/db_project","root","root");
            System.out.println("Connect");
            }
        catch(Exception ex){
            System.out.println(ex);
        }
    }
    public boolean insert(String str)
    {
        boolean bol=false;
        try{
            st=con.createStatement();
            st.executeUpdate(str);
            bol=true;
        }catch(Exception ex)
        {
            System.out.println(ex);
        }
        return bol;
    }
    public ResultSet select(String selQry)
    {
        try {
            st = con.createStatement();
            rs = st.executeQuery(selQry);
        } catch (Exception ex) {
            System.out.println(ex);
        }
        return rs;
    }
}
 